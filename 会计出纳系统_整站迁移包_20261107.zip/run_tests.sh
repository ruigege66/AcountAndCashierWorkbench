#!/bin/bash
cd "$(dirname "$0")"
python3 run_tests.py "$@"
