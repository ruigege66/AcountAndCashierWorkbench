#!/bin/bash
cd "$(dirname "$0")"
if [ -x "runtime/python/bin/python3" ]; then
  PY="runtime/python/bin/python3"
else
  PY="python3"
fi
PORT="${PORT:-8765}"
echo "正在启动：http://127.0.0.1:$PORT"
( sleep 1; (command -v xdg-open >/dev/null && xdg-open "http://127.0.0.1:$PORT") || (command -v open >/dev/null && open "http://127.0.0.1:$PORT") ) >/dev/null 2>&1 &
exec env PORT="$PORT" "$PY" server.py
