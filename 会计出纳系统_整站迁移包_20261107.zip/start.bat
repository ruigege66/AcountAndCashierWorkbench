@echo off
chcp 65001 >nul
title 会计出纳系统
cd /d "%~dp0"
if not defined PORT set PORT=8765
echo ==========================================
echo    会计出纳系统
echo    访问地址: http://127.0.0.1:%PORT%
echo    关闭本窗口即停止服务
echo ==========================================
echo.
if not exist "server.py" goto noserver
if exist "runtime\python\python.exe" goto embed
where python >nul 2>nul
if errorlevel 1 goto nopython
set "PY=python"
goto run
:embed
set "PY=runtime\python\python.exe"
echo [启动] 使用包内自带 Python 运行时（无需安装）
goto run
:nopython
echo [错误] 未找到 Python，且包内没有 runtime 运行时目录。
echo 请使用完整的整站迁移包，或安装 Python 3.9 及以上版本。
echo.
pause
exit /b 1
:noserver
echo [错误] 当前目录缺少 server.py，压缩包可能没有完整解压。
echo 当前目录: %CD%
echo.
pause
exit /b 1
:run
echo [启动] %PY% server.py
echo.
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://127.0.0.1:%PORT%'"
"%PY%" server.py
set "CODE=%ERRORLEVEL%"
echo.
echo [已停止] 退出码 %CODE%
if not "%CODE%"=="0" (
  echo 启动失败，请把上面的错误信息截图反馈；
  echo 也可双击 启动（诊断）.bat 查看运行环境。
)
echo.
pause
