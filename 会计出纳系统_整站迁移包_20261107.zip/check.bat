@echo off
chcp 65001 >nul
title 会计出纳系统 - 环境诊断
cd /d "%~dp0"
echo 当前目录: %CD%
echo.
echo [1] 关键文件检查
if exist "server.py" (echo   server.py 存在) else (echo   [缺失] server.py)
if exist "db.py" (echo   db.py 存在) else (echo   [缺失] db.py)
if exist "office.py" (echo   office.py 存在) else (echo   [缺失] office.py)
if exist "data\journal.db" (echo   数据库 data\journal.db 存在) else (echo   [缺失] data\journal.db)
echo.
echo [2] 内置运行时
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" -c "import sys,sqlite3;print('  Python',sys.version.split()[0]);print('  SQLite',sqlite3.sqlite_version)"
) else (
  echo   [缺失] runtime\python\python.exe
)
echo.
echo [3] 系统 Python
where python 2>nul || echo   [未安装或未加入 PATH]
echo.
echo [4] 端口占用（8765）
netstat -ano | findstr :8765 || echo   端口空闲
echo.
echo 提示：如果双击 启动.bat 一闪而过，请把本窗口内容截图反馈。
echo 如果压缩包来自网络，右键 zip - 属性 - 勾选“解除锁定”后再解压。
echo.
pause
